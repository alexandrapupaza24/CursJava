package curs11;

public class TestTextFileProcessor {

	public static void main(String[] args) {
	TextFileProcessor obj = new TextFileProcessor();
	obj.writeFile("Masina");
	obj.readTxtFile();

	}

}
