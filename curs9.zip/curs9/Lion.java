package curs9;

public class Lion extends WildAnimal{
	
	@Override
	public void makeSound() {
		System.out.println("Roaaar!");
	}
	
	public void eatMeat() {
		System.out.println("I eat meat and I like it!");
	}

}
