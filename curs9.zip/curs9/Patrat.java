package curs9;

public class Patrat extends Shape{
	

}
