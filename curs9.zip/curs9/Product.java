package curs9;

public abstract class Product {
	//o clasa abstracta are in interiorul ei atat metode care au implementare cat si care nu au implementare
	
	public abstract int calculatePrice();
	
	public void productRaiting() {
		
		System.out.println("Riating produsului: nu mai incerc!");
	}

}
