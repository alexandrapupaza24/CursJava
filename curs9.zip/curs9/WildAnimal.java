package curs9;

public class WildAnimal {
	
	public void makeSound() {
		System.out.println("Make an animal sound.");
	}

}
