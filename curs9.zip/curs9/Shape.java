package curs9;

public class Shape {
	
	public void draw() {
		System.out.println("Clasa SHAPE");
		System.out.println("Deseneaza forme generice!");
	}

}
