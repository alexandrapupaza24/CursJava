package curs9;

public class TestEncapsulare {

	public static void main(String[] args) {
		ExempluEncapsulare encapsulareObj= new ExempluEncapsulare(-10);
		encapsulareObj.getNumar();
		System.out.println(encapsulareObj.getNumar());
		

	}

}
