package curs9;

public class MobilePhone extends Product {

	@Override
	public int calculatePrice() {
		
		return 0;
	}

}
