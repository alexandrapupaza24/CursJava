package curs9;

public class Deer extends WildAnimal {
	
	@Override
	public void makeSound() {
		System.out.println("Meeee!");
	}
	public void eatGrass() {
		System.out.println("I eat grass and I like it!");
	}

}
