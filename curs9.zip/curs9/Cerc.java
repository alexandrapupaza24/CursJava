package curs9;

public class Cerc extends Shape{
	
	public void draw() {
		System.out.println("Clasa CERC");
		System.out.println("Deseneaza un cerc!");
	}

}
