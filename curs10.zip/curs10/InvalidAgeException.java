package curs10;

public class InvalidAgeException extends Exception {
	
	public InvalidAgeException(String mesaj) {
		super(mesaj);
		
	}

}
